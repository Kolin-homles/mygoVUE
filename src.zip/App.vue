<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

<style>
html,body,#app{
    height: 100%;
    width: 100%;
    margin: 0;
}
</style>