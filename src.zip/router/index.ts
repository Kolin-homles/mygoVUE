import { createRouter, createWebHistory } from 'vue-router'
import login from '../views/login.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login',
      component: login
    },
    {
      path: '/about',
      name: 'about',
      component: () => import('../views/AboutView.vue'),
    },
    {
      path: '/test',
      name: 'test',
      component: () => import('../views/test.vue'),
    },
    {
      path: '/register',
      name: 'register',
      component: () => import('../views/register.vue'),
    }, 
    {
      path: '/layout',
      name: 'layout',
      component: () => import('../views/layout.vue'),
    },
    {
      path: '/home',
      name: 'home',
      component: () => import('../views/home.vue'),
      children: [
        {
          path: '/home/user',
          name: 'user',
          component: () => import('../views/user.vue') 
        },
        {
          path: '/home/item',
          name: 'item',
          component: () => import('../views/item.vue')
        },
         {
            path: '/home/aichat',
            component: () => import('../views/aichat.vue'),
          },
      ]
    },
   
  ],
})

export default router
